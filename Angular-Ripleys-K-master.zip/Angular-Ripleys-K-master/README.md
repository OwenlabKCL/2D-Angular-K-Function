# Angular-Ripleys-K

How to use this:

Simulated demo data is provided ('data.txt') and the analysis code 'AngularRipleysKForDemoData' should be chosen for this file to demonstrate the use of analysis.

For experimental data, for which regions of interest should be selected, there are three codes:
CroppingForROIs : This takes the raw data file from which you would like to select regions for analysis and outputs the Regions in seperate folders
AngularRipleysK: This then reads all of the generated Regions and performs the analysis on each as batch. 
Post-processing: This then takes the output of the regional analysis and performs post processing per region. 

